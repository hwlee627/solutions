package 퍼펙트셔플_sw_3499_2w;

public class Test {

	public static void main(String[] args) {
		int a = 5/2;
		System.out.println(a);

	}

}
