package 영준이의카드카운팅_sw_4047_2w;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 04;
		System.out.println(a);
		
		String b = "S04";
		String[] c = String.valueOf(b).split("");
		
		int d = Integer.parseInt(c[1]+c[2]);
		System.out.println(d);
		
		int f = 0 % 2;
		System.out.println(f);
	}

}
